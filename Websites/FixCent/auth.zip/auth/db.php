<?php
$host = "localhost";
$user = "DB_USERNAME";
$pass = "DB_PASSWORD";
$db   = "fixncent_db";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());
}

session_start();
?>
