<?php
include "db.php";

$otp = $_POST['otp'];
$user_id = $_SESSION['otp_user'];

$q = mysqli_query($conn, "
SELECT * FROM otp_codes 
WHERE user_id='$user_id' 
AND otp_code='$otp'
AND is_used=0
AND expires_at >= NOW()
ORDER BY id DESC LIMIT 1
");

if (mysqli_num_rows($q) == 1) {
    mysqli_query($conn, "UPDATE otp_codes SET is_used=1 WHERE user_id='$user_id'");
    $_SESSION['user_id'] = $user_id;
    header("Location: ../dashboard.php");
} else {
    echo "Invalid or Expired OTP";
}
