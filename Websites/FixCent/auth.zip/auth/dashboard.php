<?php
include "auth/db.php";
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit;
}
?>
<h2>Welcome! You are logged in ✅</h2>
<a href="auth/logout.php">Logout</a>
