<?php
include "db.php";

$phone = $_POST['phone'];

$user = mysqli_query($conn, "SELECT id FROM users WHERE phone='$phone'");
if (mysqli_num_rows($user) == 0) {
    die("User not found");
}

$row = mysqli_fetch_assoc($user);
$user_id = $row['id'];

$otp = rand(1000,9999);
$expire = date("Y-m-d H:i:s", strtotime("+5 minutes"));

mysqli_query($conn, "INSERT INTO otp_codes 
(user_id, otp_code, expires_at)
VALUES ('$user_id','$otp','$expire')");

$_SESSION['otp_user'] = $user_id;

/* Yahan SMS API lagegi — abhi testing ke liye echo */
echo "OTP (testing): <b>$otp</b>";
?>

<form method="POST" action="verify_otp.php">
<input name="otp" placeholder="Enter OTP" required>
<button>Verify OTP</button>
</form>
