<?php
include "db.php";

if (isset($_POST['register'])) {
    $name   = $_POST['full_name'];
    $phone  = $_POST['phone'];
    $email  = $_POST['email'];
    $gender = $_POST['gender'];
    $city   = $_POST['city'];

    $check = mysqli_query($conn, "SELECT id FROM users WHERE phone='$phone'");
    if (mysqli_num_rows($check) > 0) {
        $error = "Phone number already registered";
    } else {
        mysqli_query($conn, "INSERT INTO users 
        (full_name, phone, email, gender, city)
        VALUES ('$name','$phone','$email','$gender','$city')");

        header("Location: login.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
<div class="card p-4 shadow">
<h4 class="mb-3">Create Account</h4>

<?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

<form method="POST">
<input class="form-control mb-2" name="full_name" placeholder="Full Name" required>
<input class="form-control mb-2" name="phone" placeholder="Phone Number" required>
<input class="form-control mb-2" name="email" placeholder="Email">
<select class="form-control mb-2" name="gender">
<option value="">Gender</option>
<option>Male</option>
<option>Female</option>
</select>
<input class="form-control mb-3" name="city" placeholder="City">

<button class="btn btn-primary w-100" name="register">Register</button>
</form>
</div>
</div>

</body>
</html>
