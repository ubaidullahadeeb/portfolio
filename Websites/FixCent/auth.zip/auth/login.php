<?php
include "db.php";

if (isset($_SESSION['user_id'])) {
    header("Location: ../dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
<div class="card p-4 shadow">
<h4>Login with Phone</h4>

<form method="POST" action="send_otp.php">
<input class="form-control mb-3" name="phone" placeholder="Enter phone number" required>
<button class="btn btn-primary w-100">Send OTP</button>
</form>
</div>
</div>

</body>
</html>
